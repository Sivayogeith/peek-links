# Peek Links Firefox Extension
This extension is adds better and customizable link preview then the default one.

## Features 
- Customizable **Font Size**
- Customizable **Background**
- Customizable **Text Color**
- Customizable **Position** - Bottom Left / Right
