const DEFAULT_BG = "lightblue";
const DEFAULT_COLOR = "black";
const DEFAULT_FONTSIZE = 14;